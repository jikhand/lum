package com.set.dto;

import java.io.Serializable;

public class AssignmentMasterDetails implements Serializable{

}
