package com.set.model;

public class AssignmentDescription {
	private String Pagenumber;
	private StringBuffer AssignmentImageUrl;

	public String getPagenumber() {
		return Pagenumber;
	}

	public void setPagenumber(String pagenumber) {
		this.Pagenumber = pagenumber;
	}

	public StringBuffer getAssignmentImageUrl() {
		return AssignmentImageUrl;
	}

	public void setAssignmentImageUrl(StringBuffer assignmentImageUrl) {
		AssignmentImageUrl = assignmentImageUrl;
	}
}
