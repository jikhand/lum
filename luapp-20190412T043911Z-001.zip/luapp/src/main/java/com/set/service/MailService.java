package com.set.service;

import com.set.model.Mail;

public interface MailService {
	public void sendEmail(Mail mail);
}
